import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Image,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Fonts } from '../utils/theme';
import { markSnapViewed, deleteSnap } from '../utils/storage';

export default function SnapViewerScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { snap } = route.params;
  const [timeLeft, setTimeLeft] = useState(snap.timer);
  const [viewing, setViewing] = useState(false);
  const progressAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const timerRef = useRef(null);
  const progressRef = useRef(null);

  const startViewing = () => {
    if (viewing) return;
    setViewing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    // Progress bar animation
    progressRef.current = Animated.timing(progressAnim, {
      toValue: 0,
      duration: snap.timer * 1000,
      useNativeDriver: false,
    });
    progressRef.current.start();

    // Countdown
    let remaining = snap.timer;
    timerRef.current = setInterval(() => {
      remaining -= 1;
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(timerRef.current);
        handleSnapExpire();
      }
    }, 1000);
  };

  const handleSnapExpire = async () => {
    // Fade out
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 400,
      useNativeDriver: true,
    }).start(async () => {
      await markSnapViewed(snap.id);
      await deleteSnap(snap.id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      navigation.goBack();
    });
  };

  const handleRelease = () => {
    if (!viewing) return;
    // Pause/stop if user lifts finger
    clearInterval(timerRef.current);
    progressRef.current?.stop();
    handleSnapExpire();
  };

  useEffect(() => {
    return () => {
      clearInterval(timerRef.current);
    };
  }, []);

  return (
    <TouchableWithoutFeedback onPressIn={startViewing} onPressOut={handleRelease}>
      <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
        <Image source={{ uri: snap.uri }} style={StyleSheet.absoluteFill} resizeMode="cover" />

        {/* Progress bar */}
        <View style={[styles.progressTrack, { marginTop: insets.top + 8 }]}>
          <Animated.View
            style={[
              styles.progressBar,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
              },
            ]}
          />
        </View>

        {/* Timer number */}
        {viewing && (
          <View style={styles.timerBadge}>
            <Text style={styles.timerText}>{timeLeft}</Text>
          </View>
        )}

        {/* Hold to view hint */}
        {!viewing && (
          <View style={styles.hintContainer}>
            <View style={styles.hintBox}>
              <Text style={styles.hintIcon}>👁</Text>
              <Text style={styles.hintText}>Hold to view snap</Text>
              <Text style={styles.hintSub}>Disappears after {snap.timer}s</Text>
            </View>
          </View>
        )}
      </Animated.View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  progressTrack: {
    position: 'absolute',
    top: 0,
    left: 12,
    right: 12,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: 2,
  },
  timerBadge: {
    position: 'absolute',
    top: 60,
    right: 20,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  timerText: {
    color: '#fff',
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.bold,
  },
  hintContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  hintBox: {
    alignItems: 'center',
    gap: 8,
  },
  hintIcon: {
    fontSize: 48,
  },
  hintText: {
    color: '#fff',
    fontSize: Fonts.sizes.xl,
    fontWeight: Fonts.weights.bold,
  },
  hintSub: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: Fonts.sizes.sm,
  },
});
