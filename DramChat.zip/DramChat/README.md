# DramChat 👻

Snapchat clone built with React Native + Expo. Local-first MVP — no backend required.

## Features
- 📸 Camera with front/back switch + flash control
- ⏱ Snap timer (1s / 3s / 5s / 7s / 10s) — photo disappears after viewing
- 🎞 Stories — local, expire after 24 hours
- 📥 Inbox — view saved snaps
- 🌑 Dark UI with electric violet accent

## Stack
- React Native + Expo SDK 51
- expo-camera, expo-av, expo-media-library
- AsyncStorage + expo-file-system (local storage)
- React Navigation (bottom tabs + stack)
- EAS Build (APK)

---

## Local Development

```bash
npm install
npx expo start
```

Scan the QR code with **Expo Go** app on your phone.

---

## Build APK via GitHub Actions

### 1. Setup EXPO_TOKEN secret

1. Go to [expo.dev](https://expo.dev) → Account Settings → Access Tokens
2. Create a new token
3. In your GitHub repo → Settings → Secrets → Actions
4. Add `EXPO_TOKEN` with the value

### 2. Push to main

GitHub Actions will:
- Build the APK via EAS
- Zip it into `DramChat-release.zip`
- Upload as a downloadable artifact

### 3. Download

Go to **Actions** tab → latest workflow run → **Artifacts** → download `DramChat-APK`

---

## Project Structure

```
DramChat/
├── App.js                        # Entry point
├── app.json                      # Expo config
├── eas.json                      # EAS Build profiles
├── src/
│   ├── screens/
│   │   ├── CameraScreen.js       # Camera + capture
│   │   ├── SnapPreviewScreen.js  # Preview + timer select
│   │   ├── SnapViewerScreen.js   # View snap (countdown)
│   │   ├── InboxScreen.js        # Saved snaps list
│   │   └── StoriesScreen.js      # Stories (24h local)
│   ├── navigation/
│   │   └── AppNavigator.js       # Tab + stack nav
│   └── utils/
│       ├── theme.js              # Colors, fonts, spacing
│       └── storage.js            # AsyncStorage + FileSystem
└── .github/workflows/
    └── build.yml                 # CI/CD → APK → ZIP
```

## Next Steps (online features)
- [ ] Firebase Auth (phone number login)
- [ ] Firestore — sync snaps/stories to cloud
- [ ] Real-time chat (Firestore or Socket.io)
- [ ] Push notifications (Expo Notifications)
- [ ] Friends list
