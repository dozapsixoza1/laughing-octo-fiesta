import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  Dimensions,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { Colors, Fonts, Spacing, Radius } from '../utils/theme';
import { getStories, deleteStory } from '../utils/storage';

const { width: SCREEN_W } = Dimensions.get('window');

function StoryRing({ story, onPress }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    Animated.sequence([
      Animated.spring(scaleAnim, { toValue: 0.92, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }),
    ]).start();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress(story);
  };

  const hoursLeft = Math.max(
    0,
    Math.floor((24 * 3600 * 1000 - (Date.now() - story.createdAt)) / 3600000)
  );

  return (
    <TouchableOpacity activeOpacity={0.9} onPress={handlePress}>
      <Animated.View style={[styles.storyRingWrap, { transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.storyRing}>
          <Image source={{ uri: story.uri }} style={styles.storyThumb} />
        </View>
        <Text style={styles.storyLabel}>{hoursLeft}h left</Text>
      </Animated.View>
    </TouchableOpacity>
  );
}

export default function StoriesScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [stories, setStories] = useState([]);
  const [activeStory, setActiveStory] = useState(null);
  const [viewProgress, setViewProgress] = useState(0);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const timerRef = useRef(null);

  const loadStories = useCallback(async () => {
    const data = await getStories();
    setStories(data);
  }, []);

  useFocusEffect(useCallback(() => {
    loadStories();
    return () => {
      clearInterval(timerRef.current);
    };
  }, [loadStories]));

  const openStory = (story) => {
    setActiveStory(story);
    progressAnim.setValue(0);
    Animated.timing(progressAnim, {
      toValue: 1,
      duration: story.duration * 1000,
      useNativeDriver: false,
    }).start(({ finished }) => {
      if (finished) closeStory(story);
    });
  };

  const closeStory = async (story) => {
    setActiveStory(null);
    progressAnim.setValue(0);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Story viewer overlay */}
      {activeStory && (
        <TouchableOpacity
          style={StyleSheet.absoluteFill}
          activeOpacity={1}
          onPress={() => closeStory(activeStory)}
        >
          <Image
            source={{ uri: activeStory.uri }}
            style={StyleSheet.absoluteFill}
            resizeMode="cover"
          />
          {/* Progress bar */}
          <View style={styles.storyProgressTrack}>
            <Animated.View
              style={[
                styles.storyProgressBar,
                {
                  width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%'],
                  }),
                },
              ]}
            />
          </View>
          <View style={[styles.storyTopBar, { paddingTop: insets.top + 12 }]}>
            <Text style={styles.storyUsername}>My Story</Text>
            <TouchableOpacity onPress={() => closeStory(activeStory)}>
              <Text style={styles.closeBtn}>✕</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      )}

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Stories</Text>
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => navigation.navigate('Camera')}
        >
          <Text style={styles.addBtnText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {stories.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>🎞</Text>
          <Text style={styles.emptyText}>No stories yet</Text>
          <Text style={styles.emptySub}>Stories disappear after 24 hours</Text>
          <TouchableOpacity
            style={styles.createBtn}
            onPress={() => navigation.navigate('Camera')}
          >
            <Text style={styles.createBtnText}>📸 Create Story</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.storiesGrid}>
          <Text style={styles.sectionLabel}>My Stories</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.storyRow}>
            {stories.map(story => (
              <StoryRing key={story.id} story={story} onPress={openStory} />
            ))}
          </ScrollView>

          <Text style={styles.sectionLabel}>All Stories</Text>
          <View style={styles.gridList}>
            {stories.map(story => (
              <TouchableOpacity
                key={story.id}
                style={styles.gridCard}
                onPress={() => openStory(story)}
                activeOpacity={0.85}
              >
                <Image source={{ uri: story.uri }} style={styles.gridImg} />
                <View style={styles.gridInfo}>
                  <Text style={styles.gridTime}>
                    {new Date(story.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                  <Text style={styles.gridDuration}>{story.duration}s</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    color: Colors.text,
    fontSize: Fonts.sizes.xxl,
    fontWeight: Fonts.weights.black,
  },
  addBtn: {
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: Radius.full,
  },
  addBtnText: {
    color: Colors.text,
    fontWeight: Fonts.weights.bold,
    fontSize: Fonts.sizes.sm,
  },
  storiesGrid: {
    padding: Spacing.md,
    gap: Spacing.md,
  },
  sectionLabel: {
    color: Colors.textSecondary,
    fontSize: Fonts.sizes.sm,
    fontWeight: Fonts.weights.semibold,
    marginBottom: Spacing.sm,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  storyRow: {
    marginBottom: Spacing.md,
  },
  storyRingWrap: {
    alignItems: 'center',
    marginRight: Spacing.md,
    gap: 4,
  },
  storyRing: {
    width: 72,
    height: 72,
    borderRadius: Radius.full,
    padding: 2,
    borderWidth: 3,
    borderColor: Colors.accent,
    overflow: 'hidden',
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 6,
  },
  storyThumb: {
    width: '100%',
    height: '100%',
    borderRadius: Radius.full,
  },
  storyLabel: {
    color: Colors.textSecondary,
    fontSize: Fonts.sizes.xs,
  },
  gridList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  gridCard: {
    width: (SCREEN_W - Spacing.md * 2 - Spacing.sm) / 2,
    height: 160,
    borderRadius: Radius.md,
    overflow: 'hidden',
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  gridImg: {
    width: '100%',
    height: '100%',
  },
  gridInfo: {
    position: 'absolute',
    bottom: Spacing.sm,
    left: Spacing.sm,
    right: Spacing.sm,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  gridTime: {
    color: Colors.text,
    fontSize: Fonts.sizes.xs,
    fontWeight: Fonts.weights.medium,
    textShadowColor: '#000',
    textShadowRadius: 4,
  },
  gridDuration: {
    color: Colors.accentLight,
    fontSize: Fonts.sizes.xs,
    fontWeight: Fonts.weights.bold,
  },
  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  emptyIcon: { fontSize: 56 },
  emptyText: {
    color: Colors.text,
    fontSize: Fonts.sizes.xl,
    fontWeight: Fonts.weights.bold,
  },
  emptySub: {
    color: Colors.textMuted,
    fontSize: Fonts.sizes.sm,
  },
  createBtn: {
    marginTop: Spacing.sm,
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.full,
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },
  createBtnText: {
    color: Colors.text,
    fontWeight: Fonts.weights.bold,
    fontSize: Fonts.sizes.md,
  },
  // Story viewer
  storyProgressTrack: {
    position: 'absolute',
    top: 8,
    left: 12,
    right: 12,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.35)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  storyProgressBar: {
    height: '100%',
    backgroundColor: '#fff',
  },
  storyTopBar: {
    position: 'absolute',
    top: 0,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storyUsername: {
    color: '#fff',
    fontWeight: Fonts.weights.bold,
    fontSize: Fonts.sizes.md,
    textShadowColor: '#000',
    textShadowRadius: 6,
  },
  closeBtn: {
    color: '#fff',
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.bold,
  },
});
