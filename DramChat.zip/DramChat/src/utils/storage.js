import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const SNAPS_KEY = 'dramchat_snaps';
const STORIES_KEY = 'dramchat_stories';
const VIEWED_KEY = 'dramchat_viewed';

// ─── Snap Storage ───────────────────────────────────────────────────────────

export async function saveSnap(snap) {
  try {
    const existing = await getSnaps();
    const updated = [snap, ...existing];
    await AsyncStorage.setItem(SNAPS_KEY, JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('saveSnap error:', e);
    return false;
  }
}

export async function getSnaps() {
  try {
    const raw = await AsyncStorage.getItem(SNAPS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function deleteSnap(snapId) {
  try {
    const snaps = await getSnaps();
    const snap = snaps.find(s => s.id === snapId);
    // Delete the actual file
    if (snap?.uri) {
      const info = await FileSystem.getInfoAsync(snap.uri);
      if (info.exists) await FileSystem.deleteAsync(snap.uri);
    }
    const updated = snaps.filter(s => s.id !== snapId);
    await AsyncStorage.setItem(SNAPS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('deleteSnap error:', e);
  }
}

export async function markSnapViewed(snapId) {
  try {
    const viewed = await getViewedSnaps();
    if (!viewed.includes(snapId)) {
      viewed.push(snapId);
      await AsyncStorage.setItem(VIEWED_KEY, JSON.stringify(viewed));
    }
  } catch {}
}

export async function getViewedSnaps() {
  try {
    const raw = await AsyncStorage.getItem(VIEWED_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// ─── Story Storage ───────────────────────────────────────────────────────────

export async function saveStory(story) {
  try {
    const existing = await getStories();
    // Stories expire after 24 hours
    const fresh = existing.filter(
      s => Date.now() - s.createdAt < 24 * 60 * 60 * 1000
    );
    const updated = [story, ...fresh];
    await AsyncStorage.setItem(STORIES_KEY, JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('saveStory error:', e);
    return false;
  }
}

export async function getStories() {
  try {
    const raw = await AsyncStorage.getItem(STORIES_KEY);
    if (!raw) return [];
    const stories = JSON.parse(raw);
    // Filter expired (24h)
    return stories.filter(
      s => Date.now() - s.createdAt < 24 * 60 * 60 * 1000
    );
  } catch {
    return [];
  }
}

export async function deleteStory(storyId) {
  try {
    const stories = await getStories();
    const story = stories.find(s => s.id === storyId);
    if (story?.uri) {
      const info = await FileSystem.getInfoAsync(story.uri);
      if (info.exists) await FileSystem.deleteAsync(story.uri);
    }
    const updated = stories.filter(s => s.id !== storyId);
    await AsyncStorage.setItem(STORIES_KEY, JSON.stringify(updated));
  } catch {}
}

// ─── File helpers ────────────────────────────────────────────────────────────

export async function copyToAppStorage(uri, type = 'snap') {
  try {
    const dir = FileSystem.documentDirectory + `dramchat/${type}s/`;
    await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
    const ext = uri.split('.').pop() || 'jpg';
    const filename = `${type}_${Date.now()}.${ext}`;
    const dest = dir + filename;
    await FileSystem.copyAsync({ from: uri, to: dest });
    return dest;
  } catch (e) {
    console.error('copyToAppStorage error:', e);
    return uri;
  }
}
