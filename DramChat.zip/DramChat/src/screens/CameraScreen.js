import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Animated,
  Alert,
  Platform,
} from 'react-native';
import { CameraView, useCameraPermissions, useMicrophonePermissions } from 'expo-camera';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Fonts, Spacing, Radius, SNAP_TIMERS, DEFAULT_SNAP_TIMER } from '../utils/theme';
import { copyToAppStorage, saveSnap } from '../utils/storage';

export default function CameraScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [micPermission, requestMicPermission] = useMicrophonePermissions();
  const [facing, setFacing] = useState('back');
  const [flash, setFlash] = useState('off');
  const [snapTimer, setSnapTimer] = useState(DEFAULT_SNAP_TIMER);
  const [showTimerPicker, setShowTimerPicker] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const cameraRef = useRef(null);
  const captureScale = useRef(new Animated.Value(1)).current;
  const timerPickerAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    (async () => {
      if (!cameraPermission?.granted) await requestCameraPermission();
      if (!micPermission?.granted) await requestMicPermission();
    })();
  }, []);

  const animateCaptureBtn = useCallback((pressed) => {
    Animated.spring(captureScale, {
      toValue: pressed ? 0.88 : 1,
      useNativeDriver: true,
      speed: 40,
      bounciness: 8,
    }).start();
  }, [captureScale]);

  const toggleTimerPicker = () => {
    const show = !showTimerPicker;
    setShowTimerPicker(show);
    Animated.spring(timerPickerAnim, {
      toValue: show ? 1 : 0,
      useNativeDriver: true,
      speed: 20,
      bounciness: 6,
    }).start();
  };

  const handleCapture = async () => {
    if (isCapturing || !cameraRef.current) return;
    setIsCapturing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    animateCaptureBtn(true);

    try {
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.85,
        base64: false,
        skipProcessing: false,
      });

      const savedUri = await copyToAppStorage(photo.uri, 'snap');
      const snap = {
        id: `snap_${Date.now()}`,
        uri: savedUri,
        timer: snapTimer,
        createdAt: Date.now(),
        type: 'photo',
      };

      await saveSnap(snap);
      animateCaptureBtn(false);

      navigation.navigate('SnapPreview', { snap });
    } catch (err) {
      console.error('Capture error:', err);
      Alert.alert('Error', 'Failed to take photo');
      animateCaptureBtn(false);
    } finally {
      setIsCapturing(false);
    }
  };

  if (!cameraPermission) return <View style={styles.container} />;

  if (!cameraPermission.granted) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text style={styles.permText}>📸 Camera access needed</Text>
        <TouchableOpacity style={styles.permBtn} onPress={requestCameraPermission}>
          <Text style={styles.permBtnText}>Allow Camera</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView
        ref={cameraRef}
        style={StyleSheet.absoluteFill}
        facing={facing}
        flash={flash}
      />

      {/* Top controls */}
      <View style={[styles.topBar, { paddingTop: insets.top + Spacing.sm }]}>
        {/* Flash toggle */}
        <TouchableOpacity
          style={styles.iconBtn}
          onPress={() => setFlash(f => f === 'off' ? 'on' : f === 'on' ? 'auto' : 'off')}
        >
          <Text style={styles.iconText}>
            {flash === 'off' ? '⚡️' : flash === 'on' ? '🔦' : '⚡A'}
          </Text>
        </TouchableOpacity>

        {/* DramChat logo */}
        <Text style={styles.logoText}>DramChat</Text>

        {/* Flip camera */}
        <TouchableOpacity
          style={styles.iconBtn}
          onPress={() => {
            Haptics.selectionAsync();
            setFacing(f => f === 'back' ? 'front' : 'back');
          }}
        >
          <Text style={styles.iconText}>🔄</Text>
        </TouchableOpacity>
      </View>

      {/* Timer picker */}
      {showTimerPicker && (
        <Animated.View
          style={[
            styles.timerPicker,
            { opacity: timerPickerAnim, transform: [{ scale: timerPickerAnim }] },
          ]}
        >
          {SNAP_TIMERS.map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.timerOption, snapTimer === t && styles.timerOptionActive]}
              onPress={() => {
                setSnapTimer(t);
                toggleTimerPicker();
                Haptics.selectionAsync();
              }}
            >
              <Text style={[styles.timerOptionText, snapTimer === t && styles.timerOptionTextActive]}>
                {t}s
              </Text>
            </TouchableOpacity>
          ))}
        </Animated.View>
      )}

      {/* Bottom controls */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + Spacing.lg }]}>
        {/* Stories shortcut */}
        <TouchableOpacity
          style={styles.sideBtn}
          onPress={() => navigation.navigate('Stories')}
        >
          <Text style={styles.sideBtnIcon}>🎞</Text>
          <Text style={styles.sideBtnLabel}>Stories</Text>
        </TouchableOpacity>

        {/* Capture button */}
        <TouchableWithoutFeedback
          onPressIn={() => animateCaptureBtn(true)}
          onPressOut={handleCapture}
        >
          <Animated.View style={[styles.captureBtn, { transform: [{ scale: captureScale }] }]}>
            <View style={styles.captureBtnInner} />
          </Animated.View>
        </TouchableWithoutFeedback>

        {/* Timer selector */}
        <TouchableOpacity style={styles.sideBtn} onPress={toggleTimerPicker}>
          <Text style={styles.sideBtnIcon}>⏱</Text>
          <Text style={styles.sideBtnLabel}>{snapTimer}s</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.sm,
  },
  iconBtn: {
    width: 44,
    height: 44,
    borderRadius: Radius.full,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconText: {
    fontSize: 20,
  },
  logoText: {
    color: Colors.text,
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.black,
    letterSpacing: 1,
    textShadowColor: Colors.accent,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  timerPicker: {
    position: 'absolute',
    bottom: 180,
    right: Spacing.xl,
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  timerOption: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
  },
  timerOptionActive: {
    backgroundColor: Colors.accent,
  },
  timerOptionText: {
    color: Colors.textSecondary,
    fontSize: Fonts.sizes.md,
    fontWeight: Fonts.weights.semibold,
  },
  timerOptionTextActive: {
    color: Colors.text,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: Spacing.xl,
  },
  captureBtn: {
    width: 84,
    height: 84,
    borderRadius: Radius.full,
    borderWidth: 4,
    borderColor: Colors.text,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
  },
  captureBtnInner: {
    width: 64,
    height: 64,
    borderRadius: Radius.full,
    backgroundColor: Colors.text,
  },
  sideBtn: {
    alignItems: 'center',
    gap: 4,
    width: 60,
  },
  sideBtnIcon: {
    fontSize: 26,
  },
  sideBtnLabel: {
    color: Colors.text,
    fontSize: Fonts.sizes.xs,
    fontWeight: Fonts.weights.medium,
  },
  permText: {
    color: Colors.text,
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.semibold,
  },
  permBtn: {
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.full,
  },
  permBtnText: {
    color: Colors.text,
    fontWeight: Fonts.weights.bold,
  },
});
