export const Colors = {
  // DramChat signature palette — deep purple/black with electric violet accent
  background: '#0A0A0F',
  surface: '#12121A',
  surfaceLight: '#1C1C28',
  border: '#2A2A3D',

  accent: '#7B2FFF',       // electric violet
  accentLight: '#9B5FFF',
  accentGlow: 'rgba(123, 47, 255, 0.25)',

  danger: '#FF3B5C',
  success: '#00E5A0',
  warning: '#FFB800',

  text: '#FFFFFF',
  textSecondary: '#A0A0B8',
  textMuted: '#5A5A7A',

  overlay: 'rgba(0,0,0,0.6)',
  overlayLight: 'rgba(0,0,0,0.3)',
};

export const Fonts = {
  sizes: {
    xs: 11,
    sm: 13,
    md: 15,
    lg: 17,
    xl: 20,
    xxl: 26,
    hero: 34,
  },
  weights: {
    regular: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
    black: '900',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const Radius = {
  sm: 8,
  md: 16,
  lg: 24,
  full: 999,
};

// Snap timer options in seconds
export const SNAP_TIMERS = [1, 3, 5, 7, 10];
export const DEFAULT_SNAP_TIMER = 5;
