import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Fonts, Spacing, Radius, SNAP_TIMERS } from '../utils/theme';
import { saveStory } from '../utils/storage';

export default function SnapPreviewScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { snap } = route.params;
  const [selectedTimer, setSelectedTimer] = useState(snap.timer);

  const handleAddToStory = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const story = {
      id: `story_${Date.now()}`,
      uri: snap.uri,
      createdAt: Date.now(),
      type: 'photo',
      duration: selectedTimer,
    };
    await saveStory(story);
    navigation.navigate('Stories');
  };

  const handleSendAsSnap = () => {
    // In offline mode — just go to inbox
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(
      '✅ Snap Saved',
      `Snap saved with a ${selectedTimer}s timer. Go to Inbox to view it.`,
      [{ text: 'OK', onPress: () => navigation.navigate('Inbox') }]
    );
  };

  const handleDiscard = () => {
    Alert.alert('Discard?', 'This snap will be deleted.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Discard',
        style: 'destructive',
        onPress: () => navigation.goBack(),
      },
    ]);
  };

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      {/* Preview image */}
      <Image source={{ uri: snap.uri }} style={StyleSheet.absoluteFill} resizeMode="cover" />

      {/* Top bar */}
      <View style={[styles.topBar, { paddingTop: insets.top + Spacing.sm }]}>
        <TouchableOpacity style={styles.iconBtn} onPress={handleDiscard}>
          <Text style={styles.iconText}>✕</Text>
        </TouchableOpacity>
        <View style={styles.timerRow}>
          {SNAP_TIMERS.map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.timerChip, selectedTimer === t && styles.timerChipActive]}
              onPress={() => {
                setSelectedTimer(t);
                Haptics.selectionAsync();
              }}
            >
              <Text style={[styles.timerChipText, selectedTimer === t && styles.timerChipTextActive]}>
                {t}s
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Timer label */}
      <View style={styles.timerLabel}>
        <Text style={styles.timerLabelText}>⏱ Snap disappears after {selectedTimer}s</Text>
      </View>

      {/* Bottom actions */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.storyBtn} onPress={handleAddToStory}>
          <Text style={styles.storyBtnIcon}>🎞</Text>
          <Text style={styles.storyBtnText}>Add to Story</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.sendBtn} onPress={handleSendAsSnap}>
          <Text style={styles.sendBtnText}>Save Snap</Text>
          <Text style={styles.sendBtnArrow}>→</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.sm,
  },
  iconBtn: {
    width: 44,
    height: 44,
    borderRadius: Radius.full,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconText: {
    color: Colors.text,
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.bold,
  },
  timerRow: {
    flexDirection: 'row',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,0,0,0.4)',
    padding: 4,
    borderRadius: Radius.full,
  },
  timerChip: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  timerChipActive: {
    backgroundColor: Colors.accent,
  },
  timerChipText: {
    color: Colors.textSecondary,
    fontSize: Fonts.sizes.sm,
    fontWeight: Fonts.weights.semibold,
  },
  timerChipTextActive: {
    color: Colors.text,
  },
  timerLabel: {
    position: 'absolute',
    top: '45%',
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
  },
  timerLabelText: {
    color: Colors.text,
    fontSize: Fonts.sizes.sm,
    fontWeight: Fonts.weights.medium,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 40,
    left: Spacing.md,
    right: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  storyBtnIcon: {
    fontSize: 18,
  },
  storyBtnText: {
    color: Colors.text,
    fontSize: Fonts.sizes.sm,
    fontWeight: Fonts.weights.semibold,
  },
  sendBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.full,
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },
  sendBtnText: {
    color: Colors.text,
    fontSize: Fonts.sizes.md,
    fontWeight: Fonts.weights.bold,
  },
  sendBtnArrow: {
    color: Colors.text,
    fontSize: Fonts.sizes.lg,
    fontWeight: Fonts.weights.bold,
  },
});
