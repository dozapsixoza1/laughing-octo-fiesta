import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Image,
  RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Colors, Fonts, Spacing, Radius } from '../utils/theme';
import { getSnaps } from '../utils/storage';

function timeAgo(ts) {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export default function InboxScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [snaps, setSnaps] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadSnaps = useCallback(async () => {
    const data = await getSnaps();
    setSnaps(data);
  }, []);

  useFocusEffect(useCallback(() => { loadSnaps(); }, [loadSnaps]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadSnaps();
    setRefreshing(false);
  };

  const renderSnap = ({ item }) => (
    <TouchableOpacity
      style={styles.snapCard}
      onPress={() => navigation.navigate('SnapViewer', { snap: item })}
      activeOpacity={0.85}
    >
      <Image source={{ uri: item.uri }} style={styles.snapThumb} />
      <View style={styles.snapOverlay} />
      <View style={styles.snapInfo}>
        <Text style={styles.snapTime}>{timeAgo(item.createdAt)}</Text>
        <View style={styles.timerBadge}>
          <Text style={styles.timerBadgeText}>⏱ {item.timer}s</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Inbox</Text>
        <Text style={styles.headerCount}>{snaps.length} snaps</Text>
      </View>

      {snaps.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>📭</Text>
          <Text style={styles.emptyText}>No snaps yet</Text>
          <Text style={styles.emptySub}>Take a snap from the camera tab</Text>
        </View>
      ) : (
        <FlatList
          data={snaps}
          keyExtractor={item => item.id}
          renderItem={renderSnap}
          contentContainerStyle={styles.list}
          numColumns={2}
          columnWrapperStyle={styles.row}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={Colors.accent}
            />
          }
        />
      )}
    </View>
  );
}

const CARD_SIZE = 170;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    color: Colors.text,
    fontSize: Fonts.sizes.xxl,
    fontWeight: Fonts.weights.black,
  },
  headerCount: {
    color: Colors.textMuted,
    fontSize: Fonts.sizes.sm,
  },
  list: {
    padding: Spacing.sm,
  },
  row: {
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  snapCard: {
    width: CARD_SIZE,
    height: CARD_SIZE,
    borderRadius: Radius.lg,
    overflow: 'hidden',
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  snapThumb: {
    width: '100%',
    height: '100%',
  },
  snapOverlay: {
    ...StyleSheet.absoluteFillObject,
    background: 'linear-gradient(transparent 50%, rgba(0,0,0,0.7))',
  },
  snapInfo: {
    position: 'absolute',
    bottom: Spacing.sm,
    left: Spacing.sm,
    right: Spacing.sm,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  snapTime: {
    color: Colors.text,
    fontSize: Fonts.sizes.xs,
    fontWeight: Fonts.weights.medium,
    textShadowColor: '#000',
    textShadowRadius: 4,
  },
  timerBadge: {
    backgroundColor: Colors.accent,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: Radius.full,
  },
  timerBadgeText: {
    color: Colors.text,
    fontSize: Fonts.sizes.xs,
    fontWeight: Fonts.weights.bold,
  },
  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  emptyIcon: {
    fontSize: 56,
  },
  emptyText: {
    color: Colors.text,
    fontSize: Fonts.sizes.xl,
    fontWeight: Fonts.weights.bold,
  },
  emptySub: {
    color: Colors.textMuted,
    fontSize: Fonts.sizes.sm,
  },
});
